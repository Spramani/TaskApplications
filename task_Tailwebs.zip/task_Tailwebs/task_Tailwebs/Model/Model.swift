//
//  Model.swift
//  task_Tailwebs
//
//  Created by Shubham Ramani on 16/03/24.
//

import Foundation

struct data {
    var date:String
    var totalTime:String
    var time:String
    var amount:String
    
}
